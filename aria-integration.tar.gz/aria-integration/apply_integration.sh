#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────
# Aria integration apply script
#
# Applies four integration fixes to a sovereign-agent checkout:
#   1. remove two empty ghost directories left by an old brace-expansion bug
#   2. rename the doctor/ package -> doctor_sentinels/ (un-shadows doctor.py)
#   3. install the event-emitting workflow loop          (agentic_loop.py)
#   4. install the LLM-backed natural-language planner    (natural_language.py
#      + handlers/__init__.py + doctor_sentinels/__init__.py)
#
# Safe to re-run (idempotent). Uses `git mv` when inside a git repo so the
# rename keeps history; falls back to plain `mv` otherwise.
#
# USAGE:
#   cd /path/to/sovereign-agent          # the repo root (has pyproject.toml)
#   bash /path/to/aria-integration/apply_integration.sh
# ─────────────────────────────────────────────────────────────────────────
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PAYLOAD="$SCRIPT_DIR/payload"
PKG="src/sovereign_agent"

say()  { printf '  %s\n' "$*"; }
ok()   { printf '  \033[32m✓\033[0m %s\n' "$*"; }
warn() { printf '  \033[33m!\033[0m %s\n' "$*"; }
die()  { printf '\033[31mABORT:\033[0m %s\n' "$*" >&2; exit 1; }

# ── Preflight ────────────────────────────────────────────────────────────
echo "── Preflight ─────────────────────────────────────────────"
[ -f "pyproject.toml" ] || die "run me from the repo root (no pyproject.toml here)."
grep -q 'sovereign' pyproject.toml 2>/dev/null || warn "pyproject.toml doesn't mention 'sovereign' — make sure this is the right repo."
[ -d "$PKG" ] || die "no $PKG/ directory — wrong location?"
[ -d "$PAYLOAD" ] || die "payload/ not found next to this script."
USE_GIT=0; if git rev-parse --is-inside-work-tree >/dev/null 2>&1; then USE_GIT=1; ok "git repo detected — rename will preserve history"; else warn "not a git repo — using plain mv (no history)"; fi
ok "repo root looks correct"

# ── Fix 1: ghost directories ─────────────────────────────────────────────
echo "── Fix 1: remove ghost directories ───────────────────────"
removed=0
# Names contain literal braces; quote hard so the shell never brace-expands.
for ghost in '{core,feedback}' '{workflow' '{workflow/handlers,doctor}'; do
  if [ -e "$PKG/$ghost" ]; then rm -rf "$PKG/$ghost" && ok "removed $PKG/$ghost" && removed=1; fi
done
[ "$removed" -eq 1 ] || say "no ghost directories present (already clean)"

# ── Fix 2: doctor/ -> doctor_sentinels/ ──────────────────────────────────
echo "── Fix 2: un-shadow doctor.py (rename package) ────────────"
if [ -d "$PKG/doctor" ] && [ ! -d "$PKG/doctor_sentinels" ]; then
  if [ "$USE_GIT" -eq 1 ]; then git mv "$PKG/doctor" "$PKG/doctor_sentinels"; else mv "$PKG/doctor" "$PKG/doctor_sentinels"; fi
  ok "renamed doctor/ -> doctor_sentinels/"
elif [ -d "$PKG/doctor_sentinels" ]; then
  say "doctor_sentinels/ already exists (rename already applied)"
  [ -d "$PKG/doctor" ] && warn "BOTH doctor/ and doctor_sentinels/ exist — inspect manually before continuing."
else
  warn "no doctor/ package found; nothing to rename"
fi
[ -f "$PKG/doctor.py" ] || warn "expected $PKG/doctor.py (the 34KB diagnostic) not found."

# ── Fixes 3 & 4: install changed files ───────────────────────────────────
echo "── Fixes 3 & 4: install changed files ────────────────────"
mkdir -p "$PKG/doctor_sentinels" "$PKG/workflow/handlers"
while IFS= read -r rel; do
  src="$PAYLOAD/$rel"; dst="$rel"
  mkdir -p "$(dirname "$dst")"
  cp "$src" "$dst"
  ok "wrote $dst"
done < <(cd "$PAYLOAD" && find . -type f | sed 's#^\./##')

# ── Compile check ────────────────────────────────────────────────────────
echo "── Byte-compile changed files ────────────────────────────"
python3 -m py_compile \
  "$PKG/workflow/agentic_loop.py" \
  "$PKG/workflow/handlers/natural_language.py" \
  "$PKG/workflow/handlers/__init__.py" \
  "$PKG/doctor_sentinels/__init__.py" \
  && ok "all changed files compile"

echo
echo "── Done. Next steps ──────────────────────────────────────"
echo "  pip install -e '.[dev]'        # if not already installed"
echo "  python -c 'import sovereign_agent.doctor; import sovereign_agent.doctor_sentinels; import sovereign_agent.workflow.handlers; print(\"imports OK\")'"
echo "  pytest -q                      # expect: 1558 passed, 1 skipped"
echo
echo "  Rollback instructions are in ROLLBACK.md next to this script."
