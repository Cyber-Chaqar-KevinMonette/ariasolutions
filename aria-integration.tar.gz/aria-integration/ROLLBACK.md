# Rollback

Every fix reverses cleanly. `PKG = src/sovereign_agent`.

## Fix 4 + 3 — changed files (planner + event-emitting loop)
These are the four files the script overwrote. If you applied inside git, the
fastest rollback is to restore them from your last commit:

```bash
git checkout -- \
  src/sovereign_agent/workflow/agentic_loop.py \
  src/sovereign_agent/workflow/handlers/natural_language.py \
  src/sovereign_agent/workflow/handlers/__init__.py \
  src/sovereign_agent/doctor_sentinels/__init__.py
```

If you are NOT in git, keep a copy of the originals before running the script
(`cp -r src/sovereign_agent /tmp/sa.bak`) and restore from there.

Behavior-only fallbacks (no file changes needed):
- `export SOV_NO_LLM_PLANNER=1` — forces the planner back to pure regex; never
  calls Ollama. The deterministic path is unchanged from before this work.
- `export SOV_NO_NL_PLANNER=1` — disables the gated NL run entirely.

## Fix 2 — doctor rename
```bash
git mv src/sovereign_agent/doctor_sentinels src/sovereign_agent/doctor   # or: mv
```
Then revert `doctor_sentinels/__init__.py` (its one import line points at
`sovereign_agent.doctor_sentinels.doctor`; the original pointed at
`sovereign_agent.doctor.doctor`). The `git checkout` above already covers this
if the directory name is restored first.

Note: reverting the rename re-introduces the original bug — the `doctor/`
package shadows the top-level `doctor.py`, so `from sovereign_agent.doctor
import run_diagnostic` breaks again and the doctor test suites fail. Only roll
this back if you are also reverting the rest.

## Fix 1 — ghost directories
Not recoverable by rollback and not worth recovering: they were empty
artifacts of an old brace-expansion bug. To recreate them (you won't want to):
`mkdir -p 'src/sovereign_agent/{core,feedback}'` etc.

---

## What changed, in one paragraph
`workflow/agentic_loop.py` now imports `emit_event` and wraps the single
`step()` dispatch boundary with `workflow-step-start-d` / `-done-d` /
`-blocked-d` events (via a fail-safe `_emit` that can never break the loop).
`workflow/handlers/natural_language.py` gains `LLMNaturalLanguagePlanner`: it
runs the existing regex patterns first (no LLM cost on a match) and only on a
miss asks the local model through the existing `OllamaClient`, using a system
prompt built from `aria_values.yaml` via the existing `build_system_prompt`.
Every failure path — kill switch, values missing, Ollama unreachable, malformed
JSON, unknown action kind — degrades to the same deterministic `note` step the
old planner produced, now carrying a visible `reason`. Hallucinated action
kinds are demoted to notes, so a bad plan can never reach an execution handler;
real execution still passes the maturity gate and each handler's own
allowlist. `GatedAgenticRun` now defaults to this planner and emits
`workflow-intake-d` / `-refused-d` / `-clarify-d` / `-simulated-d` /
`-complete-d` across its lifecycle. The handlers package exports the new class.
No new top-level subsystem; no change to `aria.py` ↔ `aria_values.yaml`.
